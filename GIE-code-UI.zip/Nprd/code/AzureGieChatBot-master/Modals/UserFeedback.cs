﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QnABot.Modals
{
    public class UserFeedback
    {
        public string UserMessage;
        public String BotMessage;
        public string Feedback;
    }
}

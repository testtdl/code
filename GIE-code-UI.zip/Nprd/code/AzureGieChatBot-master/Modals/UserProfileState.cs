﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QnABot.Modals
{
    public class UserProfileState
    {
        public string Name { get; set; }
    }
}

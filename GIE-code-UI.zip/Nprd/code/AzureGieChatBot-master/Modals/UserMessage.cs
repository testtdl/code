﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QnABot.Modals
{
    public class UserMessage
    {
        public string Timestamp;
        public String UserResponse;
        public string BotResponse;
    }
}

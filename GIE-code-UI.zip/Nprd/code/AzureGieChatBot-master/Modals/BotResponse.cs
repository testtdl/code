﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QnABot.Modals
{
    public class BotResponse
    {
        public List<Answers> answers{get;}=new List<Answers>();
    }
}

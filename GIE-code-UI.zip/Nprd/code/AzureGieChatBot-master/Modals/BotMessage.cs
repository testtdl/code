﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QnABot.Modals
{
    public class BotMessage
    {
        public string timestamp;
        public String message;
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QnABot.Modals
{
    public class Answers
    {
        public List<String> questions{get;}=new List<String>();
        public string answer;
        public string score;
        public string id;
        public string source;

    }
}

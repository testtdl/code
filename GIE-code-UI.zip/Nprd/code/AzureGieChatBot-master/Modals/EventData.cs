﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QnABot.Modals
{
    public class EventData
    {
        public string UserId { get; set; }

        public List<UserMessage> UserMessages { get; } = new List<UserMessage>();

       // public List<BotMessage> BotMessages { get; } = new List<BotMessage>();

        public List<UserFeedback> UserFeedbacks { get; } = new List<UserFeedback>();
    }

}

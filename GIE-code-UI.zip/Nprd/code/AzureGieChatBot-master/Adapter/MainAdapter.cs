﻿using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Integration.AspNet.Core;
using Microsoft.Bot.Connector.Authentication;
using Microsoft.Bot.Schema;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QnABot.Adapter
{
    public class MainAdapter:BotFrameworkHttpAdapter
    {
        public MainAdapter(
            ICredentialProvider credentialProvider,
            IChannelProvider channelProvider,
            ConversationState conversationState,
            IBotTelemetryClient telemetryClient
           )
            : base(credentialProvider, channelProvider)
        {
            OnTurnError = async (turnContext, exception) =>
            {
                await turnContext.SendActivityAsync(new Activity(type: ActivityTypes.Trace, text: $"Exception Message: {exception.Message}, Stack: {exception.StackTrace}"));
                telemetryClient.TrackException(exception);
            };

        }
    }
}

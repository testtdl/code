﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace QnABot.Utils
{
    public class QnAMakerParser
    {
        /**
        * Sends a HTTP-request to the QnA Maker API
        */
        public async static Task<string> Post(string uri,string body)
        {
            using (var client = new HttpClient())
            using (var request = new HttpRequestMessage())
            {
                request.Method = HttpMethod.Post;
                request.RequestUri = new Uri(uri);
                request.Content = new StringContent(body, Encoding.UTF8, "application/json");
                request.Headers.Add("Authorization", "EndpointKey 1e73a15e-42d6-40ea-bda0-46abbd3788d8");
                var response = await client.SendAsync(request);

                return await response.Content.ReadAsStringAsync();
            }
        }
        /**
     * Gets the URI to the QnA Maker API
     */
        private static string GetUri()
        {
            string method = "/knowledgebases/" + "d8127013-b33f-4605-aa0d-142a4e0067a3" + "/generateAnswer/";
            return "https://gie-chatbot.azurewebsites.net/qnamaker" + method;
        }


        public static async Task<string> GetMetadata(string question)
        {
            string response = await Post(GetUri(), GetJsonQuestion(question));
            dynamic json = JsonConvert.DeserializeObject(response);
            try
            {
                Console.WriteLine(json.answers[0].metadata[0].value);
                return json.answers[0].metadata[0].value;
            }
            catch (Exception e) {
                return null;
            }
        }

        /**
        * Serializes a string to json, suitable for sending as API request
        */
        private static string GetJsonQuestion(string question)
        {
            return @"
            {
                'question': '" + question.Replace('\'', ' ') + @"',
            }
            ";
        }

       /**
       * Gets the confidence score from the QnA Maker API of a given question
       */

        public static async Task<double> GetScore(string question)
        {
            string response = await Post(GetUri(), GetJsonQuestion(question));
            dynamic json = JsonConvert.DeserializeObject(response);
            return (double)json.answers[0].score;
        }

        /**
       * Gets the answer from the QnA Maker API of a given question
       */
        public static async Task<string> GetAnswer(string question)
        {
            string response = await Post(GetUri(), GetJsonQuestion(question));
            dynamic json = JsonConvert.DeserializeObject(response);
            Console.WriteLine("\n \n\n\n\n\n\n\n\n\n\n\n\n\n Answer" + json.answers[0].answer);
            return json.answers[0].answer;
        }

        /**
        * Gets the area metadata tag from the QnA Maker API of a given question
        */
        public async static Task<string> GetArea(string question)
        {
            string response = await Post(GetUri(), GetJsonQuestion(question));
            response = response.Substring(response.IndexOf("\"name\":\"area\""));
            for (int i = 0; i < 7; i++)
            {
                response = response.Substring(response.IndexOf("\""));
                response = response.Substring(1);
            }
            response = response.Substring(0, response.IndexOf("\""));
            return response;
        }


    }
}

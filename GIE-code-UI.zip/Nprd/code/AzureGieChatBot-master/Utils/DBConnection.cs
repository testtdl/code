﻿using Microsoft.Azure.Cosmos;
using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Microsoft.Bot.Builder;
using Microsoft.Extensions.Configuration;
using QnABot.Modals;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QnABot.Utils
{
    public  class DBConnection
    {
        private readonly CosmosClient _cosmosClient;
        private readonly Microsoft.Azure.Cosmos.Database _database;
        private readonly Container _container;
        private static DocumentClient client;


        public DBConnection(IConfiguration configuration)
        {
            _cosmosClient = new CosmosClient(configuration["CosmosDbEndpoint"],configuration["CosmosDbAuthKey"]);
            _database = _cosmosClient.GetDatabase(configuration["CosmosDbDatabaseId"]);
            _container =  _database.GetContainer(configuration["CosmosDbDatabaseId"]); 
        }

        public async Task QueryItemsAsync(string id,EventData eventData)
        {
            var sqlQueryText = "SELECT * FROM c where c.id.document.EventData.UserId.='" + id+"'";

            Console.WriteLine("Running query: {0}\n", sqlQueryText);
            EventData querySalesOrder = client.CreateDocumentQuery<EventData>(
               UriFactory.CreateDocumentCollectionUri("absgie", "absgie"))
               .Where(so => so.UserId == id)
               .AsEnumerable()
               .First();

            ResourceResponse<Document> response = await client.ReplaceDocumentAsync(
                UriFactory.CreateDocumentUri("absgie", "absgie", eventData.UserId),
                eventData);

            var updated = response.Resource;
            QueryDefinition queryDefinition = new QueryDefinition(sqlQueryText);
            FeedIterator<EventData> queryResultSetIterator = _container.GetItemQueryIterator<EventData>(queryDefinition);
            
            List<EventData> families = new List<EventData>();
           
        }
    }
}

﻿// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Bot.Builder.AI.QnA;
using Microsoft.Bot.Builder.AI.QnA.Dialogs;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Extensions.DependencyInjection;

using Microsoft.Recognizers.Text.DataTypes.TimexExpression;
using System.Linq;
using Microsoft.Bot.Builder.Dialogs.Choices;
using Microsoft.Bot.Builder;
using System;
using QnABot.Modals;
using Microsoft.Bot.Schema;
using QnABot.Dialog;
using Microsoft.Extensions.Logging;
using QnABot.Utils;

namespace Microsoft.BotBuilderSamples.Dialog
{
    /// <summary>
    /// This is an example root dialog. Replace this with your applications.
    /// </summary>
    public class RootDialog : MainInterruptor
    {

        /// <summary>
        /// QnA Maker initial dialog
        /// </summary>
        private const string InitialDialog = "initial-dialog";
        protected readonly BotState _ConversationState;
        protected readonly Bot.Builder.Dialogs.Dialog Dialog;
        protected readonly BotState _UserState;
        protected string UserResponse;
        protected string BotResponse;
        protected string Timestamp;
        protected string[] DefaultGreeting = { "hi", "hello", "hello there!","hey","heyy","ok","ohk","okk","sure","cool"};
        protected readonly IBotServices _botServices;
        protected readonly ILogger<RootDialog> Logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="RootDialog"/> class.
        /// </summary>
        /// <param name="services">Bot Services.</param>
        public RootDialog(IBotServices services, IServiceProvider serviceProvider,ILogger<RootDialog> _logger)
            : base(nameof(RootDialog))
        {

            _botServices = services;
            Logger = _logger;
            
/*          AddDialog(new ChoicePrompt(nameof(ChoicePrompt)));*/
            
            // Adding the QnA Maker dialog into ROOT Dialog
            AddDialog(new QnAMakerBaseDialog(services));

            // Adding Waterfall Dialog
            AddDialog(new WaterfallDialog(nameof(WaterfallDialog), new WaterfallStep[]{
                InitialStepAsync,
                RecognizeGreetingAndChitChatStepAsync,
                FinalStepAsync,
            }));

            // The initial child Dialog to run.
            InitialDialogId = nameof(WaterfallDialog);

            _ConversationState = serviceProvider.GetService<ConversationState>();
            _UserState = serviceProvider.GetService<UserState>();
        }

        
        private async Task<DialogTurnResult> InitialStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
             //Logger.LogInformation("Checking the user feedback condition.");
            if (stepContext.Context.Activity.Text.ToLower().Contains("oui") || stepContext.Context.Activity.Text.ToLower().Contains("non"))
            {
                //Logger.LogInformation("Calling the FeedbackStepAsync Method");
                await FeedbackStepAsync(stepContext.Context, cancellationToken);
                return await stepContext.CancelAllDialogsAsync();
            }

            return await stepContext.BeginDialogAsync(nameof(QnAMakerDialog), null, cancellationToken);
        }

        private async Task<DialogTurnResult> RecognizeGreetingAndChitChatStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            if (string.IsNullOrEmpty(stepContext.Context.Activity.Text))
            {
                return await stepContext.EndDialogAsync();
            }
            try
            {
                //Logger.LogInformation("Getting metadata of current message!");
                // Getting Metadata of user message
                string metadata = await QnAMakerParser.GetMetadata(stepContext.Context.Activity.Text);
                if (metadata.ToLower().Contains("chitchat") && !string.IsNullOrEmpty(metadata))
                {
                    return await stepContext.EndDialogAsync();
                }

            }
            catch(Exception e)
            {
                //Logger.LogInformation("Metadata not found!");
            }
            // Checking for default greeting
            if (DefaultGreeting.Contains(stepContext.Context.Activity.Text.ToLower()))
            {
                return await stepContext.EndDialogAsync();

            }
            return await stepContext.NextAsync();
        }

        /*
         * 
         * Final Step of waterfall dialog to store the conversation between user and bot into database instead of chitchat.
         * 
         */
        private async Task<DialogTurnResult> FinalStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            var conversationStateAccessors = _ConversationState.CreateProperty<EventData>(nameof(EventData));
            var conversationData = await conversationStateAccessors.GetAsync(stepContext.Context, () => new EventData());

            var userStateAccessors = _UserState.CreateProperty<UserProfileState>(nameof(UserProfileState));
            var userProfile = await userStateAccessors.GetAsync(stepContext.Context, () => new UserProfileState());
            try
            {

                Timestamp = stepContext.Context.Activity.Timestamp.ToString();
                UserResponse = stepContext.Context.Activity.Text;
                BotResponse = _botServices.QnAMakerService.GetAnswersAsync(stepContext.Context).Result[0].Answer;
              //  BotResponse = await QnAMakerParser.GetAnswer(stepContext.Context.Activity.Text);


                conversationData.UserId = stepContext.Context.Activity.Conversation.Id;

                UserMessage userMessage = new UserMessage();
                userMessage.UserResponse = UserResponse;
                userMessage.BotResponse = BotResponse;
                userMessage.Timestamp = stepContext.Context.Activity.Timestamp.ToString();
                conversationData.UserMessages.Add(userMessage);

                await SendSuggestedActionsAsync(stepContext.Context, cancellationToken);

            }
            catch(Exception e)
            {
                //await stepContext.Context.SendActivityAsync("Sorry!, I don't have answer of your question");
            }
            
            return await stepContext.EndDialogAsync();
        }

        /*
         * 
         * Save the user feedback on Bot's response.
         * 
         */
        private async Task FeedbackStepAsync(ITurnContext stepContext, CancellationToken cancellationToken)
        {

            var text = stepContext.Activity.Text.ToLower();
            if (text.Contains("oui") || text.Contains("non"))
            {

                var conversationStateAccessors = _ConversationState.CreateProperty<EventData>(nameof(EventData));
                var conversationData = await conversationStateAccessors.GetAsync(stepContext, () => new EventData());

                var userStateAccessors = _UserState.CreateProperty<UserProfileState>(nameof(UserProfileState));
                var userProfile = await userStateAccessors.GetAsync(stepContext, () => new UserProfileState());
                UserFeedback userFeedback = new UserFeedback();

                if (text.Contains("non"))
                {
                    //Logger.LogInformation("User gave a negative feedback.");
                    userFeedback.Feedback = "Non";
                    userFeedback.BotMessage = BotResponse;
                    userFeedback.UserMessage = UserResponse;
                    //Logger.LogInformation("Saving the user feedback");
                    conversationData.UserFeedbacks.Add(userFeedback);

                    await stepContext.SendActivityAsync(MessageFactory.Text($"Désolé, je vais tâcher de m’améliorer. Je t’invite à consulter [notre site](https://axa365.sharepoint.com/sites/GIE_AXA_External/Majunga/SitePages/Home.aspx) pour trouver ce que tu cherches"), cancellationToken);
                }
                else
                {
                    //Logger.LogInformation("User gave a positive feedback.");
                    userFeedback.BotMessage = BotResponse;
                    userFeedback.UserMessage = UserResponse;
                    userFeedback.Feedback = "Oui";
                    //Logger.LogInformation("Saving the user feedback");
                    conversationData.UserFeedbacks.Add(userFeedback);
                }
            }
        }


        private static async Task SendSuggestedActionsAsync(ITurnContext turnContext, CancellationToken cancellationToken)
        {
            if (!turnContext.Activity.Text.ToLower().Contains("oui") || !turnContext.Activity.Text.ToLower().Contains("non"))
            {
                List<CardAction> actions = new List<CardAction>();
                actions.Add(new CardAction()
                {
                    DisplayText = "👍",
                    Text = "👍",
                    Title = "👍",
                    Value = "Oui",
                    Type = ActionTypes.ImBack
                });
                actions.Add(new CardAction()
                {
                    DisplayText = "👎",
                    Text = "👎",
                    Title = "👎",
                    Value = "Non",
                    Type = ActionTypes.ImBack
                });

                SuggestedActions suggestedActions = new SuggestedActions()
                {
                    Actions = actions
                };
                var reply = turnContext.Activity.CreateReply("La réponse est-elle utile?");
                reply.SuggestedActions = suggestedActions;
                await turnContext.SendActivityAsync(reply, cancellationToken);
            }
        }


    }
}

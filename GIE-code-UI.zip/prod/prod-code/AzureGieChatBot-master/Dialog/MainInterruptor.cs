﻿using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Extensions.DependencyInjection;

using Microsoft.Bot.Schema;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using QnABot.Modals;
using Microsoft.BotBuilderSamples;

namespace QnABot.Dialog
{
    public class MainInterruptor:ComponentDialog
    {
        protected readonly BotState _conversationState;
        protected readonly BotState _userState;
        protected string[] defaultGreeting = { "hi", "hello", "hello there!", "hey", "heyy", "ok", "ohk", "okk", "sure", "cool" };


        public MainInterruptor(string id)
        : base(id)
        {}


        protected override async Task<DialogTurnResult> OnBeginDialogAsync(DialogContext innerDc, object options, CancellationToken cancellationToken)
        {
            var result = await InterruptAsync(innerDc, cancellationToken);
            if (result != null)
            {
                return result;
            }

            return await base.OnBeginDialogAsync(innerDc, options, cancellationToken);
        }

        protected override async Task<DialogTurnResult> OnContinueDialogAsync(DialogContext innerDc, CancellationToken cancellationToken)
        {
            var result = await InterruptAsync(innerDc, cancellationToken);
            if (result != null)
            {
                return result;
            }

            return await base.OnContinueDialogAsync(innerDc, cancellationToken);
        }

        private async Task<DialogTurnResult> InterruptAsync(DialogContext innerDc, CancellationToken cancellationToken)
        {
      
            if (innerDc.Context.Activity.Type == ActivityTypes.Message)
            {
                var text = innerDc.Context.Activity.Text.ToLower();
                switch (text)
                {

                 /*   case "intro":
                    case "help":
                    case "help!":
                    case "help me":
                    case "help us":
                        await SendIntroCardAsync(innerDc.Context, cancellationToken);
                        return await innerDc.CancelAllDialogsAsync();*/

                    case "hi":
                    case "hello":
                    case "hey":
                    case "hey there!":
                    case "hey there":
                    case "hello there!":
                    case "hello there":
                    case "hola":
                    case "heyy":
                    case "helloo":
                    case "hii":
                    case "bonjour":
                        await innerDc.Context.SendActivityAsync($"Bonjour!");
                        return await innerDc.CancelAllDialogsAsync();

                }
            }
            return null;
        }


        private static async Task SendIntroCardAsync(ITurnContext turnContext, CancellationToken cancellationToken)
        {
            var card = new HeroCard
            {
                Title = "Welcome to GIE Bot Assistant!",
                Text = @"Welcome to Welcome Users bot sample! This Introduction card
                 is a great way to introduce your Bot to the user and suggest
                 some things to get them started. We use this opportunity to
                 recommend a few next steps for learning more creating and deploying bots.",
                Images = new List<CardImage>() { new CardImage("https://aka.ms/bf-welcome-card-image") },
                Buttons = new List<CardAction>()
                {
                    new CardAction(ActionTypes.ImBack, "Get an overview", null, "Get an overview", "Get an overview", "Send HR Report"),
                    new CardAction(ActionTypes.ImBack, "Ask a question", null, "Ask a question", "Ask a question", ""),
                    new CardAction(ActionTypes.ImBack, "Learn how to deploy", null, "Learn how to deploy", "Learn how to deploy", ""),
                }
            };
            var response = MessageFactory.Attachment(card.ToAttachment());
            await turnContext.SendActivityAsync(response, cancellationToken);
        }


    }
}
